import { randomUUID } from "crypto";

export default () => randomUUID();