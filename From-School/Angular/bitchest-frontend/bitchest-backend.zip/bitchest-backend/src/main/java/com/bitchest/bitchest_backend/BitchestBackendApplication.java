package com.bitchest.bitchest_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BitchestBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(BitchestBackendApplication.class, args);
	}

}
