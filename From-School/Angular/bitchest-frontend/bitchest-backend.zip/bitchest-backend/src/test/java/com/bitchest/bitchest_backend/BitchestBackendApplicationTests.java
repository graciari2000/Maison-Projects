package com.bitchest.bitchest_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BitchestBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
